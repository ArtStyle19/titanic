<?php
header('Content-Type: application/json');

// Obtener datos de la solicitud
$tipo = $_POST['tipo'] ?? '';
$numero = $_POST['numero'] ?? '';

if (!$tipo || !$numero) {
    echo json_encode(['error' => 'Tipo de consulta o número no proporcionado.']);
    exit;
}

$token = 'apis-token-12396.GEAgnGAZfOg9Ww6nAzkFkxPiadFIFI7J';
$response = '';

if ($tipo === 'DNI') {
    // Consulta por DNI
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.apis.net.pe/v2/reniec/dni?numero=' . $numero,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'Referer: https://apis.net.pe/consulta-dni-api',
            'Authorization: Bearer ' . $token
        ),
    ));

    $response = curl_exec($curl);
    curl_close($curl);
} elseif ($tipo === 'RUC') {
    // Consulta por RUC
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.apis.net.pe/v2/sunat/ruc?numero=' . $numero,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'Referer: http://apis.net.pe/api-ruc',
            'Authorization: Bearer ' . $token
        ),
    ));

    $response = curl_exec($curl);
    curl_close($curl);
} else {
    echo json_encode(['error' => 'Tipo de consulta inválido.']);
    exit;
}

// Enviar respuesta al cliente
if ($response) {
    echo $response;
} else {
    echo json_encode(['error' => 'No se obtuvo respuesta de la API.']);
}
?>

