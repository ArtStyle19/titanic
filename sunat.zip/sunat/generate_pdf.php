<?php
require('libs/fpdf.php');

// Decode query parameters
$emisor = json_decode(base64_decode($_GET['emisor']), true);
$cliente = json_decode(base64_decode($_GET['cliente']), true);
$comprobante = json_decode(base64_decode($_GET['comprobante']), true);
$detalle = json_decode(base64_decode($_GET['detalle']), true);

// Create PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(190, 10, 'Comprobante de Pago', 0, 1, 'C');
$pdf->Ln(10);

// Emisor data
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(190, 10, 'Datos del Emisor', 0, 1);
$pdf->SetFont('Arial', '', 10);
foreach ($emisor as $key => $value) {
    $pdf->Cell(95, 8, ucfirst($key) . ': ' . $value, 0, 1);
}
$pdf->Ln(5);

// Cliente data
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(190, 10, 'Datos del Cliente', 0, 1);
$pdf->SetFont('Arial', '', 10);
foreach ($cliente as $key => $value) {
    $pdf->Cell(95, 8, ucfirst($key) . ': ' . $value, 0, 1);
}
$pdf->Ln(5);

// Comprobante detail
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(190, 10, 'Detalle del Comprobante', 0, 1);
$pdf->SetFont('Arial', '', 10);

// Table headers
$pdf->Cell(40, 10, 'Producto', 1);
$pdf->Cell(20, 10, 'Cantidad', 1);
$pdf->Cell(40, 10, 'Precio Unitario', 1);
$pdf->Cell(40, 10, 'Valor Total', 1);
$pdf->Ln();

// Table data
foreach ($detalle as $item) {
    $pdf->Cell(40, 10, $item['descripcion'] ?? '', 1);
    $pdf->Cell(20, 10, $item['cantidad'] ?? '', 1);
    $pdf->Cell(40, 10, number_format($item['precio_unitario'], 2), 1);
    $pdf->Cell(40, 10, number_format($item['importe_total'], 2), 1);
    $pdf->Ln();
}

// Output the PDF
$pdf->Output('I', 'Comprobante.pdf');
exit;
?>

