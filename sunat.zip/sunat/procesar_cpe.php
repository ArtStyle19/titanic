<?php
// Incluir las clases necesarias para generar y enviar el CPE
require_once('./api/api_genera_xml.php');
require_once('./api/api_cpe.php');
require_once('./cantidad_en_letras.php');

// Recibir datos del formulario
$emisor = $_POST['emisor'];
$cliente = $_POST['cliente'];
$comprobante = $_POST['comprobante'];


// echo var_dump($comprobante);
$detalle = $_POST['detalle'];

// Calcular los totales del comprobante
$total_opgravadas = 0.00;
$total_opexoneradas = 0.00;
$total_opinafectas = 0.00;
$total_opimpbolsas = 0.00;
$total = 0.00;
$igv = 0.00;
$op_gratuitas1 = 0.00;
$op_gratuitas2 = 0.00;

foreach ($detalle as $key => $value) {
    if ($value['tipo_afectacion_igv'] == 10) { // Operaciones gravadas
        $total_opgravadas += $value['valor_total'];
    }

    if ($value['tipo_afectacion_igv'] == 20) { // Operaciones exoneradas
        $total_opexoneradas += $value['valor_total'];
    }

    if ($value['tipo_afectacion_igv'] == 30) { // Operaciones inafectas
        $total_opinafectas += $value['valor_total'];
    }

    $igv += $value['igv'];
    $total_opimpbolsas = $value['total_impuesto_bolsas'];
    $total += $value['importe_total'] + $total_opimpbolsas;
}
$comprobante['total_opgravadas'] = $total_opgravadas;
$comprobante['total_opexoneradas'] = $total_opexoneradas;
$comprobante['total_opinafectas'] = $total_opinafectas;
$comprobante['total_impbolsas'] = $total_opimpbolsas;
$comprobante['total_opgratuitas_1'] = $op_gratuitas1;
$comprobante['total_opgratuitas_2'] = $op_gratuitas2;

$comprobante['igv'] = $igv;
$comprobante['total'] = $total;
$comprobante['total_texto'] = CantidadEnLetra($total);
$comprobante['forma_pago'] = 'Contado';
$comprobante['monto_pendiente'] = 0;

// Crear el XML del comprobante
$obj_xml = new api_genera_xml();
$nombreXML = $emisor['nrodoc'] . '-' . $comprobante['tipodoc'] . '-' . $comprobante['serie'] . '-' . $comprobante['correlativo'];
$rutaXML = 'xml/';
$obj_xml->crea_xml_invoice($rutaXML . $nombreXML, $emisor, $cliente, $comprobante, $detalle);

echo '</br> PARTE 01: XML DE FACTURA CREADO SATISFACTORIAMENTE';

// Enviar el comprobante electrónico a Sunat
$objEnvio = new api_cpe();
$ruta_certificado = 'certificado_digital/';
$ruta_archivo_xml = 'xml/';
$ruta_archivo_cdr = 'cdr/';
$estado_envio = $objEnvio->enviar_invoice($emisor, $nombreXML, $ruta_certificado, $ruta_archivo_xml, $ruta_archivo_cdr);

// Mostrar el resultado del envío
echo '</br> PARTE 02: ENVÍO CPE-SUNAT';
echo '</br> Estado de envío: ' . $estado_envio['estado'];
echo '</br> Mensaje: ' . $estado_envio['estado_mensaje'];
echo '</br> HASH_CPE: ' . $estado_envio['hash_cpe'];
echo '</br> Descripción: ' . $estado_envio['descripcion'];
echo '</br> Nota: ' . $estado_envio['nota'];
echo '</br> Código de error: ' . $estado_envio['codigo_error'];
echo '</br> Mensaje de error: ' . $estado_envio['mensaje_error'];
echo '</br> HTTP CODE: ' . $estado_envio['http_code'];
echo '</br> OUTPUT: ' . $estado_envio['output'];

// Encode data for PDF generation
$query_data = http_build_query([
    'emisor' => base64_encode(json_encode($emisor)),
    'cliente' => base64_encode(json_encode($cliente)),
    'comprobante' => base64_encode(json_encode($comprobante)),
    'detalle' => base64_encode(json_encode($detalle)),
]);

echo "<a href='generate_pdf.php?$query_data' target='_blank'>Download PDF</a>";



?>

